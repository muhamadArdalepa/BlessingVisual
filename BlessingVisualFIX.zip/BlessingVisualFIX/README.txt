download & install jdk 17 & netbeans 12
https://download.oracle.com/java/17/latest/jdk-17_windows-x64_bin.exe


created by kelompok 1
muhamad ardalepa
nad