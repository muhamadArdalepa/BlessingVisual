/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blessingvisual;

/**
 *
 * @author Kamisato Ayaka
 */
public class NewClass {
    public static void main(String[] args) {
        model.updOrIns("delete from tbl_jenis where id_jenis=1");
    }
}
